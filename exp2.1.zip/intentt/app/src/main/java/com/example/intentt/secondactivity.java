package com.example.intentt;

import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;
import android.widget.TextView;
public class secondactivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState); setContentView(R.layout.activity_secondactivity);
        TextView tv=(TextView)findViewById(R.id.e1);
        TextView tv1=(TextView)findViewById(R.id.e2);
        tv.setText(getIntent().getExtras().getString("uname"));
        tv1.setText(getIntent().getExtras().getString("pwd"));
    }

}
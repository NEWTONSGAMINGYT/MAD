package com.example.mad22;

import android.app.Activity;
import android.os.*;
import android.view.View;
import android.widget.*;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    private LinearLayout linear2;
    private TextView textview1,textview2,textview3,textview4,textview5,textview6;
    private RadioGroup radiogroup2;
    private EditText edittext1;
    private Button button1,button2,button3;
    private CheckBox checkbox1,checkbox2,checkbox3;
    private RadioButton radiobutton2,radiobutton3,radiobutton4;
    
    @Override
    protected void onCreate(Bundle _savedInstanceState) {
        super.onCreate(_savedInstanceState);
        setContentView(R.layout.activity_main);
        initialize(_savedInstanceState);
    }
    //made by Shubham Kumar
    private void initialize(Bundle _savedInstanceState) {
        linear2 = findViewById(R.id.linear2);
        textview1 = findViewById(R.id.textview1);
        radiogroup2 = findViewById(R.id.radiogroup2);
        button1 = findViewById(R.id.button1);
        textview4 = findViewById(R.id.textview4);
        textview5 = findViewById(R.id.textview5);
        edittext1 = findViewById(R.id.edittext1);
        button2 = findViewById(R.id.button2);
        textview2 = findViewById(R.id.textview2);
        textview6 = findViewById(R.id.textview6);
        checkbox1 = findViewById(R.id.checkbox1);
        checkbox2 = findViewById(R.id.checkbox2);
        checkbox3 = findViewById(R.id.checkbox3);
        button3 = findViewById(R.id.button3);
        textview3 = findViewById(R.id.textview3);
        radiobutton2 = findViewById(R.id.radiobutton2);
        radiobutton3 = findViewById(R.id.radiobutton3);
        radiobutton4 = findViewById(R.id.radiobutton4);
        
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View _view) {
                if (radiobutton2.isChecked()) {
                    textview4.setText(radiobutton2.getText().toString());
                }
                if (radiobutton3.isChecked()) {
                    textview4.setText(radiobutton3.getText().toString());
                }
                if (radiobutton4.isChecked()) {
                    textview4.setText(radiobutton4.getText().toString());
                }
            }
        });
        
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View _view) {
                textview2.setText(edittext1.getText().toString());
            }
        });
        
        button3.setOnClickListener(new View.OnClickListener() {
            String msg1="";
            @Override
            public void onClick(View _view) {
                if (checkbox1.isChecked()) {
                    msg1=msg1+checkbox1.getText().toString();
                    textview3.setText(msg1);
                }
                if (checkbox2.isChecked()) {
                    msg1=msg1+", "+checkbox2.getText().toString();
                    textview3.setText(msg1);
                }
                if (checkbox3.isChecked()) {
                    msg1=msg1+", "+checkbox3.getText().toString();
                    textview3.setText(msg1);
                }
            }
        });
    }
    //made by Shubham Kumar
}